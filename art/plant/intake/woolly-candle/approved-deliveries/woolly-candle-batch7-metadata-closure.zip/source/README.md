# Woolly Candle — candle@2 source candidate

**Status:** PMO visual review required. No visual acceptance or engine acceptance is asserted.

- 58 exact logical-grid PNGs: `source-canonical/`; origin `CANONICAL_REFERENCE_TRANSCRIPTION`.
- 35 exact-size salt toothed masks: `masks/`; source opaque pixels only and protected anchors / attachment points.
- Original 18-material palette **unchanged byte-for-byte** from V4: `WOOLLY_CANDLE_PRODUCTION_PALETTE_v1.json`. Its original internal `bodyPlan: candle@1` field is deliberately retained to honor the explicit byte-preservation instruction; the candidate pack and manifests declare `candle@2`.
- `atlas.png` / `atlas.json` are **provisional** candle@2 source assembly, not validated game assets.
- V4-to-candle2 per-drawing dimensions, hashes, and origin: `V4_TO_CANDLE2_CHANGE_REPORT.json`.
- Close 3-column family comparisons: `review/closeplates/` (13 individual plates).
- A 13-state composited 84x98 source preview: `review/ASSEMBLED_CANDLE2_13_STATES.png`. Native previews are not the repository engine's compositor.
- Approved visual sources copied in `review/locked-reference/`. Original Batch 1 reference includes a **rejected** trunk depiction; use it only for approved base leaves and bud. Corrected trunk reference is the accepted BASE specimen in Batch 2.
- Checksums: `SHA256SUMS.txt`; local QA: `qa/LOCAL_NATIVE_QA.json`.

## Provisional engineering dependency

Repository main still exposed the candle@1 contract during source creation. The PMO-proposed candle@2 maxima are used as provisional limits. `seedHead.large` is 24x22 (max24x24); `root.storage.3` is 18x27 (max18x28) to meet 1px margin using currently known sockets. The eventual candle@2 clip proof might require adjustments. No engine-native clip validation was claimed.

**Do not create `PMO_FINAL_ACCEPTANCE.json` or integrate pending the engineering contract + PMO sign-off.**
