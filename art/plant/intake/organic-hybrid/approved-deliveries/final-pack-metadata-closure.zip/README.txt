ORGANIC HYBRID — FINAL PACK METADATA CLOSURE (no new sprites)

organic-hybrid-final-pack-metadata.json   waxCore ramp (4, dark → light) · environment (sky, soil, turf) · render.stemOutline = "ink"
verification.json                         waxCore: 4 colours, unique, dark → light, none in the complete approved Organic Hybrid palette
                                          (65 declared colours in the six batch manifests ∪ every colour present in the 55 sprites + 6 masks);
                                          environment colours unique and disjoint from the plant palette
swatches-waxcore-environment.png          CORE · waxCore · waxLeaf · LEAF ramps and the environment colours
proof-drought-heat-waxcore-4x.png / -1x   DROUGHT T2 · + HEAT T1 · + HEAT T2 · + HEAT T3 on the final environment
proof-base-final-environment.png          the approved BASE specimen on the final environment, 1× and 3× (the 1280 room scale)

How the proofs were made: the organisms are the art studio's own approved composites (batch 3 proof, 1×: the BASE, DROUGHT T2 and
DROUGHT T2 + HEAT T3 panels), cut out of their dark backdrop pixel-for-pixel. The only pixel changes are the runtime Heat treatment the
engine performs — LEAF shade N → waxLeaf N and CORE shade N → waxCore N, on shades 2–3 (T1), 1–3 (T2) or 0–3 (T3) — and the backdrop is
painted by the production environment painter (resources/plant-visual/plant-compositor.js paintEnv) with the new colours.
Note: Heat T1 / T2 also lift leaf ANGLES at runtime (authored angle variants); the T1 / T2 panels show the treatment only, on the
approved T2 panel's angles. The T3 panel is the approved Heat-T3 composite (authored heat leaf forms).
No approved PNG was modified; nothing was ingested into the repository.
