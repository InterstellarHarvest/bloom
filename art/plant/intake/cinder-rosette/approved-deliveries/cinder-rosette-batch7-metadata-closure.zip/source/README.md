# Cinder Rosette 035C1 native fidelity V3

Status: COMPLETE PRODUCTION SOURCE CANDIDATE — PENDING PMO VISUAL FIDELITY + ENGINE INTAKE.

27 recovered exact native sprites: kept byte-identical.
33 lost sprites: reference-guided CELL transcription direct to logical dimensions. Origin CANONICAL_REFERENCE_TRANSCRIPTION, NOT RECOVERED_EXACT.
18 approved drought masks: kept byte-identical.
24 Base/Heat/Flood masks: regenerated for V3 source pixels.
Palette candidate: byte-identical to V2 (69 colours; 18 ramps).

Per-sprite review comparisons visual-equivalence/individual/<id>.png: approved reference | rejected v2 | v3.
Batch overviews visual-equivalence/overview/BATCH{1,2,4}_THREE_WAY.png.

The locked review imagery shows idealized artistic enlarged pixels; native canvas limitations require human PMO visual approval. No PMO_FINAL_ACCEPTANCE.json is included.
