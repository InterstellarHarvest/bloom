# Cinder Rosette — BLOOM-035C1 narrow correction V3.1

**Scope:** only four native sprites revised: `bud`, `root.aerial.1`, `root.aerial.2`, `root.aerial.3`.
All other 56 sprites, all 42 toothed masks, all surviving original-source PNGs, and the production palette are byte-identical to the V3 archive.
Only the four sprite hashes/provenance records were updated within `CINDER_ROSETTE_CANONICAL_MANIFEST.json` and `CINDER_ROSETTE_SOURCE_MAP.json`, plus the corresponding four checksum lines.

## Review evidence

`visual-equivalence/v3_1/LOCKED_REVIEW_V3_V3_1_COMPARISON.png` shows left: locked reference, middle: V3, right: V3.1.
Individual comparisons are available in the same directory.

This is a candidate requiring PMO fidelity review and engineering intake; not a final production atlas. No `PMO_FINAL_ACCEPTANCE.json` has been created.
