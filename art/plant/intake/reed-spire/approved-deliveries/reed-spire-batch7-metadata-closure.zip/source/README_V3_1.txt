REED SPIRE V3.1 FINAL FOUR-SPRITE CORRECTION
V3 remains the unmodified baseline. Only source-canonical/root.aerial.{1,2,3}.png and source-canonical/salt.crystal.png are new 1x PNG bytes. All 35 masks, 22 historical native originals, and canonical palette are unchanged. See V3_TO_V3_1_REPORT.json and the four review/V3_1_TRIPTYCH_*.png. No PMO_FINAL_ACCEPTANCE.json.
