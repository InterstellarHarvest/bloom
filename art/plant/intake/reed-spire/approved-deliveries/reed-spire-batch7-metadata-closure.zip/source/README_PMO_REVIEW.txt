BLOOM-035C1 V3 — NATIVE REFERENCE TRANSCRIPTION CANDIDATE

53 canonical sprites; 35 toothed masks. 22 exact original native PNGs byte-preserved. 31 revised logical-grid native PNGs, explicitly CANONICAL_REFERENCE_TRANSCRIPTION.

Palette v1 unchanged; native color mapping may differ from original historical RGB but geometry of exact sources remains unchanged. Review enlarged reference pixels NOT extracted into deliverables. See review/ for original PMO review sheets and 31 separate reference/v2/v3 triptychs.

No PMO_FINAL_ACCEPTANCE.json. PMO must visually review and run integrated atlas/checks.
